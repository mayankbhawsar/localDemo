//
//  PhotoPostViewController.swift
//  HackerKernelTask
//
//  Created by Workstation 158 on 09/01/20.
//

import UIKit
struct photoStruct:Decodable {
    let title: String
    let url: String
    let thumbnailUrl: String
}

class PhotoViewController: BaseViewController {
    
    @IBOutlet weak var tblDetails: UITableView!
    @IBOutlet weak var btnPhoto: UIButton!
    @IBOutlet weak var btnPosts: UIButton!
    
    var arrPhotodata = [photoStruct]()
    let reuseIdentifier = "ImageTableViewCell"
    override func viewDidLoad() {
        super.viewDidLoad()
        addSlideMenuButton()
        getPhotoData()
    }
    func getPhotoData() {
        let url = URL(string: "http://jsonplaceholder.typicode.com/photos")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            do {
                if error == nil {
                    self.arrPhotodata = try JSONDecoder().decode([photoStruct].self, from: data!)
                    DispatchQueue.main.async {
                        self.tblDetails!.reloadData()
                    }
                }
            } catch {
                print("Error in Json")
            }
            }.resume()
    }
    
    @IBAction func btnClickPostsViewer(_ sender: UIButton) {
        let storyVC = self.storyboard?.instantiateViewController(identifier: "PostViewController") as! PostViewController
        self.navigationController?.pushViewController(storyVC, animated: true)
    }
    
    @IBAction func btnClickPhotoViewer(_ sender: UIButton) {
        getPhotoData()
    }
    
}
extension PhotoViewController: UITableViewDelegate,UITableViewDataSource  {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrPhotodata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: reuseIdentifier, for: indexPath as IndexPath) as! ImageTableViewCell
        let imageDictionary = self.arrPhotodata[indexPath.row]
        let imageUrlString = imageDictionary.thumbnailUrl
        let imageUrl = URL(string: imageUrlString)!
        DispatchQueue.global().async {
            do {
                let imageData:NSData = try NSData(contentsOf: imageUrl as URL)
                DispatchQueue.main.async {
                    let image = UIImage(data: imageData as Data)
                    cell.imgView.image = image
                    cell.imgView.clipsToBounds = true
                    cell.imgView.layer.cornerRadius = cell.imgView.frame.width/2
                    cell.imgView.contentMode = .scaleAspectFill
                    cell.lblTitle.text = "Title: \(self.arrPhotodata[indexPath.row].title)"
                }
            }
            catch {
                print("Error in loading image from url")
            }
        }
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let detailsVC = self.storyboard?.instantiateViewController(identifier: "DetailsViewController") as! DetailsViewController
        detailsVC.imgURL = self.arrPhotodata[indexPath.row].url
        self.navigationController?.pushViewController(detailsVC, animated: true)
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
}
