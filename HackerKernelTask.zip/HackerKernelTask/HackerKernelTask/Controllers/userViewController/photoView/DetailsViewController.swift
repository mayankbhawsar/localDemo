//
//  DetailsViewController.swift
//  HackerKernelTask
//
//  Created by Workstation 158 on 09/01/20.
//

import UIKit

class DetailsViewController: BaseViewController {
    
    //    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var imgView: UIImageView!
    var imgURL: String = ""
    
    override func viewDidLoad() {
        //        addSlideMenuButton()
        super.viewDidLoad()
        do {
            let imageData = try Data(contentsOf: URL(string: imgURL)!)
            DispatchQueue.main.async {
                let image = UIImage(data: imageData as Data)
                self.imgView.image = image
            }
        } catch  {
            print("To")
        }
        
    }
}
