//
//  SignUpVC.swift
//  HackerKernelTask
//
//  Created by Workstation 158 on 09/01/20.
//

import UIKit
import CoreData
class SignUpVC: UIViewController {
    
    @IBOutlet weak var txtUsername: UITextField!
    @IBOutlet weak var txtEmailID: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnSave: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtPassword.autocorrectionType = .no
        txtPassword.isSecureTextEntry = true
        txtPassword.textContentType = .newPassword
        
        txtUsername.addBottomBorder()
        txtEmailID.addBottomBorder()
        txtPassword.addBottomBorder()
        
        txtUsername.placeholderColor = UIColor.white
        txtEmailID.placeholderColor = UIColor.white
        txtPassword.placeholderColor = UIColor.white
    }
    let vc = LoginViewController()
    @IBAction func btnClickSaveData(_ sender: UIButton) {
        let result = validation()
        if result.0 == true {
            let usno = DatabaseHelper.sharedInstance.checkUserExist(email: txtEmailID.text!)
            if usno.count < 1 {
                saveUserData()
                let alert = vc.alertMessage(alertmsg: "Thank You for Join Us")
                self.present(alert, animated: true, completion: nil)
                txtUsername.text = "";txtEmailID.text = "";txtPassword.text = "";
            }
            else {
                let alert = LoginViewController().alertMessage(alertmsg: "Email-ID Already Register With Us..!")
                self.present(alert, animated: true, completion: nil)
                txtEmailID.text = ""
            }
        }
        else {
            let alert = LoginViewController().alertMessage(alertmsg: "Please \(validation().1)")
            self.present(alert, animated: true, completion: nil)
        }
    }
}

extension SignUpVC {
    func saveUserData() {
        let userDict = [
            "userName": txtUsername!.text,
            "userEmail": txtEmailID!.text,
            "userPassword": txtPassword!.text,
        ]
        DatabaseHelper.sharedInstance.saveUserDetails(userDetails: userDict as! [String : String])
    }
    func validation() -> (Bool,String) {
        if txtUsername?.text == "" {
            return (false,"Enter Username")
        }
        else if !isValidEmail(emailStr: txtEmailID.text!) {
            return (false,"Enter Valid EmailID")
        }
        else if txtPassword?.text == "" {
            return (false,"Enter Password")
        }
        else {
            return (true,"true")
        }
    }
    func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
}

