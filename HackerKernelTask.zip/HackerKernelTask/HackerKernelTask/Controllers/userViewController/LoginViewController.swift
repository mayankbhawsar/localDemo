//
//  ViewController.swift
//  HackerKernelTask
//
//  Created by Workstation 158 on 09/01/20.
//

import UIKit
import CoreData

class LoginViewController: UIViewController {
    
    @IBOutlet weak var txtEmailID: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnSignUp: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        txtEmailID.addBottomBorder()
        txtPassword.addBottomBorder()
        txtEmailID.placeholderColor = UIColor.white
        txtPassword.placeholderColor = UIColor.white
    }
    override func viewDidAppear(_ animated: Bool) {
        let isUserLoggedIn:Bool = UserDefaults.standard.bool(forKey: "status")
        if isUserLoggedIn {
            let vc = self.storyboard?.instantiateViewController(identifier: "PhotoViewController") as! PhotoViewController
            self.navigationController?.pushViewController(vc, animated: false)
        }
    }
    @IBAction func btnClickUserLogin(_ sender: UIButton) {
        
        if validation().0 {
            let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
            let fetchRequest = NSFetchRequest<NSDictionary>(entityName: "LoginMaster")
            fetchRequest.resultType = .dictionaryResultType
            fetchRequest.predicate = NSPredicate(format: "email == %@ ",txtEmailID.text!)
            fetchRequest.propertiesToFetch = ["password"]
            do {
                let result = try context.fetch(fetchRequest)
                if result.count > 0 {
                    if (result[0].value(forKey: "password") as! String) == txtPassword.text {
                        UserLogin()
                        
                    }
                    else {
                        let alert = self.alertMessage(alertmsg: "Incorrect Password")
                        self.present(alert, animated: true, completion: nil)
                    }
                }
                else {
                    let alert = self.alertMessage(alertmsg: "Either Email or Password is Incorrect")
                    self.present(alert, animated: true, completion: nil)
                }
            } catch let error as NSError {
                print(error)
            }
        }
        else {
            let alert = self.alertMessage(alertmsg: "Please Enter \(validation().1)")
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    
    @IBAction func btnClickUserSignUp(_ sender: UIButton) {
        let goToSignUpVC = self.storyboard?.instantiateViewController(identifier: "SignUpVC") as! SignUpVC
        self.navigationController?.pushViewController(goToSignUpVC, animated: true)
    }
    func alertMessage(alertmsg: String) -> UIAlertController {
        let alert = UIAlertController(title: "Alert", message: alertmsg, preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
        return alert
    }
}
extension UITextField{
    @IBInspectable var placeholderColor: UIColor {
        get {
            return self.attributedPlaceholder?.attribute(.foregroundColor, at: 0, effectiveRange: nil) as? UIColor ?? .lightText
        }
        set {
            self.attributedPlaceholder = NSAttributedString(string: self.placeholder ?? "", attributes: [.foregroundColor: newValue])
        }
    }
    func addBottomBorder() {
        let bottomLine = CALayer()
        bottomLine.frame = CGRect(x: 0, y: self.frame.size.height - 1, width: self.frame.size.width, height: 1)
        bottomLine.backgroundColor = UIColor.white.cgColor
        borderStyle = .none
        layer.addSublayer(bottomLine)
    }
}
extension LoginViewController {
    func UserLogin()  {
        let result = DatabaseHelper.sharedInstance.checkUserExist(email: txtEmailID.text!)
        if result.count == 0 {
            let alert = self.alertMessage(alertmsg: "Please Register Your Self")
            self.present(alert, animated: true, completion: nil)
        }
        else if result.count > 0 {
            let dict:[String:String] = ["email":txtEmailID.text!,"username":result[0].value(forKey: "username") as! String]
            UserDefaults.standard.set(dict, forKey: "userDict")
            UserDefaults.standard.set(true, forKey: "status")
            txtEmailID.text = ""
            txtPassword.text = ""
            let userDetailsVC = self.storyboard?.instantiateViewController(identifier: "PhotoViewController") as! PhotoViewController
            self.navigationController?.pushViewController(userDetailsVC, animated: true)
        }
    }
    func validation() -> (Bool,String) {
        if !isValidEmail(emailStr: txtEmailID.text!) {
            return (false," Valid EmailID")
        }
        else if txtPassword?.text == "" {
            return (false," Password")
        }
        else {
            return (true,"true")
        }
    }
    func isValidEmail(emailStr:String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailPred.evaluate(with: emailStr)
    }
}
