//
//  PostViewController.swift
//  HackerKernelTask
//
//  Created by Workstation 158 on 10/01/20.
//

import UIKit
struct postStruct: Decodable {
    let title: String
    let body: String
    let id: Int
}

class PostViewController: BaseViewController, UITableViewDelegate, UITableViewDataSource {
    var arrPostdata = [postStruct]()
    var imageData:NSData? = nil
    @IBOutlet weak var tblDetails: UITableView!
    let cellIdentifier = "postViewCell"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.tblDetails.delegate = self
        self.tblDetails.dataSource = self
        getPostsData()
    }
    
    func getPostsData() {
        let url = URL(string: "http://jsonplaceholder.typicode.com/posts")
        URLSession.shared.dataTask(with: url!) { (data, response, error) in
            do {
                if error == nil {
                    self.arrPostdata = try JSONDecoder().decode([postStruct].self, from: data!)
                    DispatchQueue.main.async {
                        self.tblDetails!.reloadData()
                    }
                }
            } catch {
                print("Error in Json")
            }
            }.resume()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.arrPostdata.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath as IndexPath)
        cell.textLabel!.font = UIFont.systemFont(ofSize: 18)
        cell.detailTextLabel!.font = UIFont.systemFont(ofSize: 18)
        cell.textLabel!.text = "Description: \(self.arrPostdata[indexPath.row].body)"
        cell.detailTextLabel?.text = "Title: \(self.arrPostdata[indexPath.row].title)"
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let id = self.arrPostdata[indexPath.row].id
        let url = "http://jsonplaceholder.typicode.com/photos/"+"\(id)"
     
        getDataFromJson(url: url, parameter: "", completion: {
            response in
            let imgUrl = response["thumbnailUrl"] as! String
            let imageUrl = URL(string: imgUrl)!
            self.imageData =  NSData(contentsOf: imageUrl)
            let image = UIImage(data: self.imageData! as Data)
            let titleHead = response["title"] as! String
            let showAlert = UIAlertController(title:"Title : \(titleHead)", message: nil, preferredStyle: .alert)
            let imageView = UIImageView(frame: CGRect(x: 60, y: 100, width: 150, height: 150))
            DispatchQueue.main.async {
                imageView.image = image
                showAlert.view.addSubview(imageView)
                let height = NSLayoutConstraint(item: showAlert.view as Any, attribute: .height, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 320)
                let width = NSLayoutConstraint(item: showAlert.view as Any, attribute: .width, relatedBy: .equal, toItem: nil, attribute: .notAnAttribute, multiplier: 1, constant: 250)
                showAlert.view.addConstraint(height)
                showAlert.view.addConstraint(width)
                showAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in
                }))
                self.present(showAlert, animated: true, completion: nil)
            }
        })
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        return UIView()
    }
    func getDataFromJson(url: String, parameter: String, completion: @escaping (_ success: [String : AnyObject]) -> Void) {
        //@escaping...If a closure is passed as an argument to a function and it is invoked after the function returns, the closure is @escaping.
        let task2 = URLSession.shared.dataTask(with: URL(string: url)!) { (Data, response, error) in
            guard let data = Data, error == nil else {
                print("error=\(error ?? "" as! Error)")
                return
            }
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                print("statusCode should be 200, but is \(httpStatus.statusCode)")
                print(response!)
                return
            }
            
            let responseString  = try! JSONSerialization.jsonObject(with: data, options: .allowFragments) as! [String : AnyObject]
            completion(responseString)
        }
        task2.resume()
    }
}

