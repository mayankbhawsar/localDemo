//
//  DatabaseHelper.swift
//  HackerKernelTask
//
//  Created by Workstation 158 on 09/01/20.
//

import UIKit
import CoreData
class DatabaseHelper: NSObject {
    
    static let sharedInstance = DatabaseHelper()
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    
    func saveUserDetails(userDetails:[String:String]) {
        let userData = NSEntityDescription.insertNewObject(forEntityName: "LoginMaster", into: context) as! LoginMaster
        userData.username = (userDetails["userName"]!)
        userData.email = (userDetails["userEmail"]!)
        userData.password = (userDetails["userPassword"]!)
        do {
            try context.save()
        } catch let err {
            print("Error: \(err.localizedDescription)")
        }
    }
    func checkUserExist(email : String) -> [NSDictionary]  {
        var result : [NSDictionary]? = nil
        let fetchRequest = NSFetchRequest<NSDictionary>(entityName: "LoginMaster")
        fetchRequest.resultType = .dictionaryResultType
        fetchRequest.predicate = NSPredicate(format: "email == %@ ",email)
        do {
            result = try context.fetch(fetchRequest)
        } catch let error as NSError {
            print(error)
        }
        return result!
    }
    
}
