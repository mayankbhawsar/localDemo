//
//  ImageCollectionViewCell.swift
//  HackerKernelTask
//
//  Created by Workstation 158 on 09/01/20.
//

import UIKit

class ImageTableViewCell: UITableViewCell {
    
    @IBOutlet weak var imgView: UIImageView!
    @IBOutlet weak var lblTitle: UILabel!
}
